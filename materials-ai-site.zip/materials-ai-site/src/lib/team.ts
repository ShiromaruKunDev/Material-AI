import { promises as fs } from 'fs';
import path from 'path';
import type { TeamMember } from '@/types/team';

const teamRoot = path.join(process.cwd(), 'team');
const supportedPhotos = ['photo.jpg', 'photo.jpeg', 'photo.png', 'photo.webp'];

function getInitials(name: string) {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join('');
}

function parseInfo(slug: string, raw: string): Omit<TeamMember, 'photoDataUrl' | 'initials'> {
  const lines = raw
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);

  const labeled = Object.fromEntries(
    lines
      .map((line) => {
        const [key, ...value] = line.split(':');
        return [key.trim().toLowerCase(), value.join(':').trim()];
      })
      .filter(([, value]) => value)
  );

  const name = labeled['фио'] || labeled['имя'] || lines[0] || slug;
  const role = labeled['роль'] || lines[1] || 'Участник проекта';
  const description = labeled['описание'] || lines.slice(2).join(' ') || 'Описание профиля будет добавлено после утверждения публичной версии сайта.';

  return { slug, name, role, description };
}

async function readPhotoDataUrl(memberDir: string) {
  for (const fileName of supportedPhotos) {
    const photoPath = path.join(memberDir, fileName);
    try {
      const buffer = await fs.readFile(photoPath);
      const extension = path.extname(fileName).replace('.', '') || 'jpeg';
      const mime = extension === 'jpg' ? 'jpeg' : extension;
      return `data:image/${mime};base64,${buffer.toString('base64')}`;
    } catch {
      // Фото необязательно. Если файла нет, карточка покажет SVG-заглушку.
    }
  }

  return undefined;
}

export async function getTeamMembers(): Promise<TeamMember[]> {
  try {
    const entries = await fs.readdir(teamRoot, { withFileTypes: true });
    const directories = entries.filter((entry) => entry.isDirectory());

    const members = await Promise.all(
      directories.map(async (directory) => {
        const slug = directory.name;
        const memberDir = path.join(teamRoot, slug);
        const infoPath = path.join(memberDir, 'info.txt');

        try {
          const raw = await fs.readFile(infoPath, 'utf-8');
          const member = parseInfo(slug, raw);
          const photoDataUrl = await readPhotoDataUrl(memberDir);

          return {
            ...member,
            photoDataUrl,
            initials: getInitials(member.name)
          };
        } catch {
          return {
            slug,
            name: slug,
            role: 'Участник проекта',
            description: 'Добавьте файл info.txt, чтобы заполнить карточку участника.',
            initials: getInitials(slug)
          } satisfies TeamMember;
        }
      })
    );

    return members.sort((a, b) => a.name.localeCompare(b.name, 'ru'));
  } catch {
    return [];
  }
}
