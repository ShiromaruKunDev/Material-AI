export type TeamMember = {
  slug: string;
  name: string;
  role: string;
  description: string;
  photoDataUrl?: string;
  initials: string;
};
