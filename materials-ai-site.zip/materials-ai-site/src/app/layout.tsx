import type { Metadata, Viewport } from 'next';
import { ThemeProvider } from '@/components/ThemeProvider';
import './globals.css';

export const metadata: Metadata = {
  metadataBase: new URL('https://materials-ai.ru'),
  title: {
    default: 'Materials AI — интеллектуальная оптимизация синтеза материалов',
    template: '%s | Materials AI'
  },
  description:
    'Materials AI помогает оптимизировать технологические процессы синтеза материалов на основе диагностических данных, машинного обучения и AI-ассистента.',
  keywords: [
    'Materials AI',
    'машинное обучение',
    'материаловедение',
    'микроэлектроника',
    'оптимизация синтеза',
    'диагностика материалов',
    'R&D'
  ],
  icons: [{ rel: 'icon', url: '/favicon.svg' }],
  openGraph: {
    title: 'Materials AI',
    description: 'Интеллектуальная оптимизация синтеза материалов и технологических процессов.',
    type: 'website',
    locale: 'ru_RU',
    url: 'https://materials-ai.ru'
  },
  robots: {
    index: true,
    follow: true
  }
};

export const viewport: Viewport = {
  themeColor: '#8E7ACE',
  width: 'device-width',
  initialScale: 1
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="ru" suppressHydrationWarning>
      <body>
        <ThemeProvider>{children}</ThemeProvider>
      </body>
    </html>
  );
}
