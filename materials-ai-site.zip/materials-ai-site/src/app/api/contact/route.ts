import { NextResponse } from 'next/server';

const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

type ContactPayload = {
  name?: string;
  company?: string;
  email?: string;
  phone?: string;
  message?: string;
};

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as ContactPayload;

    const name = body.name?.trim() ?? '';
    const email = body.email?.trim() ?? '';
    const message = body.message?.trim() ?? '';

    if (!name || !email || !message) {
      return NextResponse.json(
        { ok: false, message: 'Заполните имя, email и сообщение.' },
        { status: 400 }
      );
    }

    if (!emailPattern.test(email)) {
      return NextResponse.json(
        { ok: false, message: 'Проверьте корректность email.' },
        { status: 400 }
      );
    }

    // Fake API: здесь позже подключается CRM, почтовый шлюз или Telegram bot.
    await new Promise((resolve) => setTimeout(resolve, 650));

    return NextResponse.json({
      ok: true,
      message: 'Заявка принята. Мы свяжемся с вами после первичного анализа запроса.'
    });
  } catch {
    return NextResponse.json(
      { ok: false, message: 'Не удалось обработать запрос. Повторите отправку позже.' },
      { status: 500 }
    );
  }
}
