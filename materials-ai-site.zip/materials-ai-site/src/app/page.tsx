import { getTeamMembers } from '@/lib/team';
import { Header } from '@/components/Header';
import { HeroSection } from '@/sections/HeroSection';
import { ProblemSection } from '@/sections/ProblemSection';
import { SolutionSection } from '@/sections/SolutionSection';
import { HowItWorksSection } from '@/sections/HowItWorksSection';
import { ServicesSection } from '@/sections/ServicesSection';
import { PricingSection } from '@/sections/PricingSection';
import { BenefitsSection } from '@/sections/BenefitsSection';
import { TeamSection } from '@/sections/TeamSection';
import { FAQSection } from '@/sections/FAQSection';
import { ContactSection } from '@/sections/ContactSection';
import { Footer } from '@/sections/Footer';

// Команда читается из файловой системы при каждом запросе в dev/prod server mode.
export const dynamic = 'force-dynamic';

export default async function Home() {
  const teamMembers = await getTeamMembers();

  return (
    <>
      <Header />
      <main>
        <HeroSection />
        <ProblemSection />
        <SolutionSection />
        <HowItWorksSection />
        <ServicesSection />
        <PricingSection />
        <BenefitsSection />
        <TeamSection members={teamMembers} />
        <FAQSection />
        <ContactSection />
      </main>
      <Footer />
    </>
  );
}
