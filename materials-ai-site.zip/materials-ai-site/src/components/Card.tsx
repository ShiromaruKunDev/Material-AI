import { cn } from '@/lib/cn';

export function Card({
  className,
  children
}: Readonly<{ className?: string; children: React.ReactNode }>) {
  return (
    <div className={cn('glass-card rounded-3xl p-6 transition duration-300 hover:-translate-y-1 hover:shadow-premium', className)}>
      {children}
    </div>
  );
}
