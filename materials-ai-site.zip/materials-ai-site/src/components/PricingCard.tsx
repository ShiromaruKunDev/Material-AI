import { Check } from 'lucide-react';
import { ButtonLink } from '@/components/ButtonLink';
import { cn } from '@/lib/cn';

type PricingCardProps = {
  plan: {
    title: string;
    audience: string;
    description: string;
    features: string[];
    badge: string;
    featured: boolean;
  };
};

export function PricingCard({ plan }: PricingCardProps) {
  return (
    <article
      className={cn(
        'glass-card relative flex h-full flex-col rounded-3xl p-6 transition duration-300 hover:-translate-y-1 hover:shadow-premium',
        plan.featured && 'border-brand-lime/70 shadow-glow'
      )}
    >
      <div className="mb-5 inline-flex w-fit rounded-full border border-borderSoft/80 bg-background/40 px-3 py-1 text-xs font-semibold uppercase tracking-[0.16em] text-[rgb(var(--muted))]">
        {plan.badge}
      </div>
      <h3 className="text-2xl font-semibold tracking-tight">{plan.title}</h3>
      <p className="mt-2 text-sm font-semibold text-brand-violet dark:text-brand-lavender">{plan.audience}</p>
      <p className="mt-5 text-sm leading-7 text-[rgb(var(--muted))]">{plan.description}</p>

      <div className="my-7 rounded-2xl bg-background/45 p-4">
        <div className="text-xs uppercase tracking-[0.18em] text-[rgb(var(--muted))]">Стоимость</div>
        <div className="mt-2 text-2xl font-semibold">По запросу</div>
      </div>

      <ul className="grid gap-3 text-sm text-[rgb(var(--muted))]">
        {plan.features.map((feature) => (
          <li key={feature} className="flex gap-3">
            <Check className="mt-0.5 h-5 w-5 shrink-0 text-brand-lime" />
            <span>{feature}</span>
          </li>
        ))}
      </ul>

      <ButtonLink href="#contact" variant={plan.featured ? 'primary' : 'ghost'} className="mt-8 w-full">
        Оставить заявку
      </ButtonLink>
    </article>
  );
}
