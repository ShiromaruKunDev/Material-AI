import type { TeamMember } from '@/types/team';

export function TeamCard({ member }: Readonly<{ member: TeamMember }>) {
  return (
    <article className="glass-card group overflow-hidden rounded-3xl p-4 transition duration-300 hover:-translate-y-1 hover:shadow-premium">
      <div className="relative aspect-[4/3] overflow-hidden rounded-[1.35rem] bg-hero-radial">
        {member.photoDataUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={member.photoDataUrl} alt={member.name} className="h-full w-full object-cover transition duration-500 group-hover:scale-105" />
        ) : (
          <div className="flex h-full w-full items-center justify-center">
            <div className="flex h-24 w-24 items-center justify-center rounded-3xl border border-white/30 bg-white/20 text-3xl font-black text-white shadow-glow backdrop-blur">
              {member.initials}
            </div>
          </div>
        )}
      </div>
      <div className="p-2 pt-5">
        <h3 className="text-xl font-semibold tracking-tight">{member.name}</h3>
        <p className="mt-2 text-sm font-semibold text-brand-violet dark:text-brand-lavender">{member.role}</p>
        <p className="mt-4 text-sm leading-7 text-[rgb(var(--muted))]">{member.description}</p>
      </div>
    </article>
  );
}
