import { cn } from '@/lib/cn';

export function SectionHeader({
  eyebrow,
  title,
  text,
  centered = false
}: Readonly<{ eyebrow?: string; title: string; text?: string; centered?: boolean }>) {
  return (
    <div className={cn('mb-12 max-w-3xl', centered && 'mx-auto text-center')}>
      {eyebrow ? (
        <p className="mb-3 text-sm font-semibold uppercase tracking-[0.24em] text-brand-violet dark:text-brand-lavender">
          {eyebrow}
        </p>
      ) : null}
      <h2 className="text-3xl font-semibold tracking-tight text-foreground sm:text-4xl lg:text-5xl">{title}</h2>
      {text ? <p className="mt-5 text-base leading-8 text-[rgb(var(--muted))] sm:text-lg">{text}</p> : null}
    </div>
  );
}
