'use client';

import { motion } from 'framer-motion';
import { cn } from '@/lib/cn';

export function AnimatedSection({
  id,
  className,
  children
}: Readonly<{ id?: string; className?: string; children: React.ReactNode }>) {
  return (
    <motion.section
      id={id}
      className={cn('scroll-mt-28 py-20 sm:py-24', className)}
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-80px' }}
      transition={{ duration: 0.55, ease: 'easeOut' }}
    >
      {children}
    </motion.section>
  );
}
