import { cn } from '@/lib/cn';

export function Container({ className, children }: Readonly<{ className?: string; children: React.ReactNode }>) {
  return <div className={cn('section-shell', className)}>{children}</div>;
}
