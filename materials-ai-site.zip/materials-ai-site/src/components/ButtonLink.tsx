import Link from 'next/link';
import { cn } from '@/lib/cn';

type ButtonLinkProps = {
  href: string;
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'ghost';
  className?: string;
};

const variants = {
  primary:
    'bg-brand-lime text-brand-ink shadow-[0_14px_40px_rgba(197,227,108,0.34)] hover:-translate-y-0.5 hover:shadow-[0_18px_50px_rgba(197,227,108,0.42)]',
  secondary:
    'bg-foreground text-background hover:-translate-y-0.5 hover:shadow-premium',
  ghost: 'border border-borderSoft/80 bg-surface/60 text-foreground hover:-translate-y-0.5 hover:bg-surface'
};

export function ButtonLink({ href, children, variant = 'primary', className }: ButtonLinkProps) {
  return (
    <Link
      href={href}
      className={cn(
        'inline-flex items-center justify-center rounded-full px-6 py-3 text-sm font-semibold transition-all duration-300',
        variants[variant],
        className
      )}
    >
      {children}
    </Link>
  );
}
