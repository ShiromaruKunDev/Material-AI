'use client';

import { useState } from 'react';
import { Send } from 'lucide-react';

const initialState = {
  name: '',
  company: '',
  email: '',
  phone: '',
  message: ''
};

export function ContactForm() {
  const [form, setForm] = useState(initialState);
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [message, setMessage] = useState('');

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus('loading');
    setMessage('');

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form)
      });

      const data = (await response.json()) as { ok: boolean; message: string };

      if (!response.ok || !data.ok) {
        throw new Error(data.message);
      }

      setStatus('success');
      setMessage(data.message);
      setForm(initialState);
    } catch (error) {
      setStatus('error');
      setMessage(error instanceof Error ? error.message : 'Не удалось отправить форму.');
    }
  }

  function updateField(field: keyof typeof form, value: string) {
    setForm((current) => ({ ...current, [field]: value }));
  }

  return (
    <form onSubmit={handleSubmit} className="glass-card rounded-3xl p-5 sm:p-7">
      <div className="grid gap-4 sm:grid-cols-2">
        <input
          required
          value={form.name}
          onChange={(event) => updateField('name', event.target.value)}
          placeholder="Имя"
          className="rounded-2xl border border-borderSoft/80 bg-background/60 px-4 py-3 outline-none transition focus:border-brand-violet"
        />
        <input
          value={form.company}
          onChange={(event) => updateField('company', event.target.value)}
          placeholder="Компания"
          className="rounded-2xl border border-borderSoft/80 bg-background/60 px-4 py-3 outline-none transition focus:border-brand-violet"
        />
        <input
          required
          type="email"
          value={form.email}
          onChange={(event) => updateField('email', event.target.value)}
          placeholder="Email"
          className="rounded-2xl border border-borderSoft/80 bg-background/60 px-4 py-3 outline-none transition focus:border-brand-violet"
        />
        <input
          value={form.phone}
          onChange={(event) => updateField('phone', event.target.value)}
          placeholder="Телефон"
          className="rounded-2xl border border-borderSoft/80 bg-background/60 px-4 py-3 outline-none transition focus:border-brand-violet"
        />
      </div>

      <textarea
        required
        value={form.message}
        onChange={(event) => updateField('message', event.target.value)}
        placeholder="Опишите задачу: материал, процесс, доступные данные, требуемые свойства"
        rows={5}
        className="mt-4 w-full rounded-2xl border border-borderSoft/80 bg-background/60 px-4 py-3 outline-none transition focus:border-brand-violet"
      />

      <button
        type="submit"
        disabled={status === 'loading'}
        className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-full bg-brand-lime px-6 py-3 text-sm font-semibold text-brand-ink transition hover:-translate-y-0.5 hover:shadow-[0_18px_50px_rgba(197,227,108,0.38)] disabled:cursor-not-allowed disabled:opacity-70 sm:w-auto"
      >
        <Send size={17} />
        {status === 'loading' ? 'Отправляем...' : 'Отправить запрос'}
      </button>

      {message ? (
        <p className={status === 'success' ? 'mt-4 text-sm text-brand-lime' : 'mt-4 text-sm text-red-500'}>
          {message}
        </p>
      ) : null}
    </form>
  );
}
