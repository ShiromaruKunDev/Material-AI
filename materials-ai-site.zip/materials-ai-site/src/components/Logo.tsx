export function Logo() {
  return (
    <div className="flex items-center gap-3" aria-label="Materials AI">
      <div className="relative flex h-11 w-11 items-center justify-center rounded-2xl bg-brand-ink shadow-glow dark:bg-white">
        <span className="absolute h-6 w-6 rounded-full border-2 border-brand-violet" />
        <span className="absolute h-4 w-8 rounded-full border-b-2 border-brand-lime" />
        <span className="relative text-xs font-black text-white dark:text-brand-ink">AI</span>
      </div>
      <div className="leading-tight">
        <div className="text-sm font-bold tracking-tight">Materials AI</div>
        <div className="text-[11px] uppercase tracking-[0.18em] text-[rgb(var(--muted))]">data driven materials</div>
      </div>
    </div>
  );
}
