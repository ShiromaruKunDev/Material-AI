'use client';

import { Menu, X } from 'lucide-react';
import { useState } from 'react';
import { navItems } from '@/data/site';
import { Logo } from '@/components/Logo';
import { ThemeToggle } from '@/components/ThemeToggle';
import { ButtonLink } from '@/components/ButtonLink';
import { cn } from '@/lib/cn';

export function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-borderSoft/60 bg-background/78 backdrop-blur-2xl">
      <div className="section-shell flex h-20 items-center justify-between gap-4">
        <a href="#top" className="shrink-0" onClick={() => setOpen(false)}>
          <Logo />
        </a>

        <nav className="hidden items-center gap-1 lg:flex" aria-label="Основная навигация">
          {navItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="rounded-full px-4 py-2 text-sm font-medium text-[rgb(var(--muted))] transition hover:bg-surface hover:text-foreground"
            >
              {item.label}
            </a>
          ))}
        </nav>

        <div className="hidden items-center gap-3 lg:flex">
          <ThemeToggle />
          <ButtonLink href="#contact" variant="primary" className="px-5 py-2.5">
            Консультация
          </ButtonLink>
        </div>

        <div className="flex items-center gap-2 lg:hidden">
          <ThemeToggle />
          <button
            type="button"
            onClick={() => setOpen((value) => !value)}
            className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-borderSoft/80 bg-surface/70"
            aria-label="Открыть меню"
          >
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      <div className={cn('lg:hidden', open ? 'block' : 'hidden')}>
        <nav className="section-shell grid gap-2 pb-5" aria-label="Мобильная навигация">
          {navItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              onClick={() => setOpen(false)}
              className="rounded-2xl border border-borderSoft/60 bg-surface/70 px-4 py-3 text-sm font-medium"
            >
              {item.label}
            </a>
          ))}
        </nav>
      </div>
    </header>
  );
}
