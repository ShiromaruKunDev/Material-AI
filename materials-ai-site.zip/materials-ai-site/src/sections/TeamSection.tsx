import { AnimatedSection } from '@/components/AnimatedSection';
import { Container } from '@/components/Container';
import { SectionHeader } from '@/components/SectionHeader';
import { TeamCard } from '@/components/TeamCard';
import type { TeamMember } from '@/types/team';

export function TeamSection({ members }: Readonly<{ members: TeamMember[] }>) {
  return (
    <AnimatedSection id="team">
      <Container>
        <SectionHeader
          eyebrow="Команда"
          title="Люди, которые соединяют материалы, диагностику и машинное обучение"
          text="Карточки участников автоматически формируются из файлов в папке /team. Это позволяет обновлять команду без изменения кода страницы."
        />

        {members.length > 0 ? (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {members.map((member) => (
              <TeamCard key={member.slug} member={member} />
            ))}
          </div>
        ) : (
          <div className="glass-card rounded-3xl p-6 text-[rgb(var(--muted))]">
            Папка /team пока пуста. Добавьте подпапки участников и файлы info.txt.
          </div>
        )}
      </Container>
    </AnimatedSection>
  );
}
