import { AnimatedSection } from '@/components/AnimatedSection';
import { Card } from '@/components/Card';
import { Container } from '@/components/Container';
import { SectionHeader } from '@/components/SectionHeader';
import { services } from '@/data/services';

export function ServicesSection() {
  return (
    <AnimatedSection id="services">
      <Container>
        <SectionHeader
          eyebrow="Услуги"
          title="Практический набор работ для R&D и производства"
          text="Materials AI может использоваться как отдельный аналитический сервис, как сопровождение экспериментальной программы или как основа для локального цифрового контура предприятия."
        />

        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {services.map((service) => {
            const Icon = service.icon;
            return (
              <Card key={service.title} className="flex min-h-80 flex-col">
                <Icon className="mb-6 h-8 w-8 text-brand-violet dark:text-brand-lavender" />
                <h3 className="text-xl font-semibold">{service.title}</h3>
                <p className="mt-4 text-sm leading-7 text-[rgb(var(--muted))]">{service.text}</p>
                <ul className="mt-6 grid gap-2 text-sm text-[rgb(var(--muted))]">
                  {service.items.map((item) => (
                    <li key={item} className="rounded-2xl bg-background/45 px-3 py-2">
                      {item}
                    </li>
                  ))}
                </ul>
              </Card>
            );
          })}
        </div>
      </Container>
    </AnimatedSection>
  );
}
