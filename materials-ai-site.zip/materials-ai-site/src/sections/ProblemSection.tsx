import { AlertTriangle } from 'lucide-react';
import { AnimatedSection } from '@/components/AnimatedSection';
import { Card } from '@/components/Card';
import { Container } from '@/components/Container';
import { SectionHeader } from '@/components/SectionHeader';
import { marketPains } from '@/data/site';

export function ProblemSection() {
  return (
    <AnimatedSection id="problem">
      <Container>
        <SectionHeader
          eyebrow="Актуальность проекта"
          title="Разработка материалов остаётся дорогим и медленным процессом"
          text="Новый материал редко появляется после одного удачного эксперимента. Обычно это цикл гипотез, серий синтеза, диагностики, ручной аналитики и повторной настройки оборудования. Materials AI проектируется как цифровой слой, который сокращает число таких циклов."
        />

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {marketPains.map((pain) => (
            <Card key={pain}>
              <AlertTriangle className="mb-5 h-7 w-7 text-brand-lime" />
              <p className="text-lg font-semibold leading-7">{pain}</p>
            </Card>
          ))}
        </div>
      </Container>
    </AnimatedSection>
  );
}
