import { ArrowRight } from 'lucide-react';
import { AnimatedSection } from '@/components/AnimatedSection';
import { Container } from '@/components/Container';
import { SectionHeader } from '@/components/SectionHeader';
import { pipeline } from '@/data/site';

export function SolutionSection() {
  return (
    <AnimatedSection id="solution" className="relative">
      <Container>
        <div className="glass-card overflow-hidden rounded-[2rem] p-6 sm:p-10 lg:p-12">
          <SectionHeader
            eyebrow="Наше решение"
            title="Единый pipeline от диагностики до технологической рекомендации"
            text="Система связывает экспериментальные данные, AI-ассистента, машинное обучение и визуальную аналитику в один рабочий процесс. Цель — не просто построить модель, а дать технологу проверяемое решение для следующего шага."
          />

          <div className="grid gap-3 md:grid-cols-6">
            {pipeline.map((item, index) => (
              <div key={item} className="relative">
                <div className="flex min-h-32 items-center justify-center rounded-3xl border border-borderSoft/70 bg-background/45 p-4 text-center text-lg font-semibold">
                  {item}
                </div>
                {index < pipeline.length - 1 ? (
                  <ArrowRight className="absolute -right-4 top-1/2 z-10 hidden -translate-y-1/2 text-brand-lime md:block" />
                ) : null}
              </div>
            ))}
          </div>
        </div>
      </Container>
    </AnimatedSection>
  );
}
