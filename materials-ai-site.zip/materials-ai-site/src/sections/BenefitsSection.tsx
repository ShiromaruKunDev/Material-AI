import { CheckCircle2 } from 'lucide-react';
import { AnimatedSection } from '@/components/AnimatedSection';
import { Container } from '@/components/Container';
import { SectionHeader } from '@/components/SectionHeader';
import { benefits } from '@/data/site';

export function BenefitsSection() {
  return (
    <AnimatedSection id="benefits">
      <Container>
        <div className="grid gap-10 lg:grid-cols-[0.85fr_1.15fr] lg:items-center">
          <SectionHeader
            eyebrow="Преимущества"
            title="Сервис закрывает разрыв между экспериментом, моделью и технологическим решением"
            text="Ключевой эффект — сокращение числа дорогостоящих итераций и более управляемое принятие решений при разработке материалов."
          />

          <div className="grid gap-3 sm:grid-cols-2">
            {benefits.map((benefit) => (
              <div key={benefit} className="glass-card flex gap-3 rounded-3xl p-4">
                <CheckCircle2 className="mt-0.5 h-6 w-6 shrink-0 text-brand-lime" />
                <span className="text-sm font-medium leading-6">{benefit}</span>
              </div>
            ))}
          </div>
        </div>
      </Container>
    </AnimatedSection>
  );
}
