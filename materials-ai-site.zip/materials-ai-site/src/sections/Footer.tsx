import { Logo } from '@/components/Logo';
import { Container } from '@/components/Container';
import { navItems } from '@/data/site';

export function Footer() {
  return (
    <footer className="border-t border-borderSoft/70 py-10">
      <Container className="flex flex-col gap-7 md:flex-row md:items-center md:justify-between">
        <Logo />
        <nav className="flex flex-wrap gap-3 text-sm text-[rgb(var(--muted))]">
          {navItems.map((item) => (
            <a key={item.href} href={item.href} className="transition hover:text-foreground">
              {item.label}
            </a>
          ))}
        </nav>
        <p className="text-sm text-[rgb(var(--muted))]">© {new Date().getFullYear()} Materials AI. Все права защищены.</p>
      </Container>
    </footer>
  );
}
