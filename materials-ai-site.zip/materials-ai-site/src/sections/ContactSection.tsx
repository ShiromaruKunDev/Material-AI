import { Mail, MapPin, Phone } from 'lucide-react';
import { ContactForm } from '@/components/ContactForm';
import { AnimatedSection } from '@/components/AnimatedSection';
import { Container } from '@/components/Container';
import { SectionHeader } from '@/components/SectionHeader';
import { contacts } from '@/data/site';

export function ContactSection() {
  return (
    <AnimatedSection id="contact">
      <Container>
        <div className="grid gap-8 lg:grid-cols-[0.85fr_1.15fr] lg:items-start">
          <div>
            <SectionHeader
              eyebrow="Обратная связь"
              title="Опишите задачу — мы предложим рабочий формат пилота"
              text="Достаточно указать материал, тип процесса, доступные данные и требуемые свойства. После этого можно оценить, нужен ли анализ данных, диагностика образцов или полный цикл построения модели."
            />

            <div className="grid gap-4">
              <div className="glass-card flex items-center gap-4 rounded-3xl p-4">
                <MapPin className="text-brand-lime" />
                <span>{contacts.city}</span>
              </div>
              <a href={`tel:${contacts.phone}`} className="glass-card flex items-center gap-4 rounded-3xl p-4 transition hover:-translate-y-0.5">
                <Phone className="text-brand-lime" />
                <span>{contacts.phone}</span>
              </a>
              <a href={`mailto:${contacts.email}`} className="glass-card flex items-center gap-4 rounded-3xl p-4 transition hover:-translate-y-0.5">
                <Mail className="text-brand-lime" />
                <span>{contacts.email}</span>
              </a>
            </div>
          </div>

          <ContactForm />
        </div>
      </Container>
    </AnimatedSection>
  );
}
