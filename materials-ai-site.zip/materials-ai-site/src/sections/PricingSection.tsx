import { PricingCard } from '@/components/PricingCard';
import { AnimatedSection } from '@/components/AnimatedSection';
import { Container } from '@/components/Container';
import { SectionHeader } from '@/components/SectionHeader';
import { pricingPlans } from '@/data/pricing';

export function PricingSection() {
  return (
    <AnimatedSection id="pricing">
      <Container>
        <SectionHeader
          eyebrow="Тарифы"
          title="Форматы подключения под разные типы организаций"
          text="Стоимость зависит от объёма данных, сложности диагностики, числа моделей, требований к локальному развёртыванию и глубины сопровождения."
        />

        <div className="grid gap-5 lg:grid-cols-3">
          {pricingPlans.map((plan) => (
            <PricingCard key={plan.title} plan={plan} />
          ))}
        </div>
      </Container>
    </AnimatedSection>
  );
}
