'use client';

import { motion } from 'framer-motion';
import { ArrowRight, Cpu, DatabaseZap, LineChart } from 'lucide-react';
import { ButtonLink } from '@/components/ButtonLink';
import { Container } from '@/components/Container';
import { heroMetrics } from '@/data/site';

export function HeroSection() {
  return (
    <section id="top" className="relative overflow-hidden py-20 sm:py-28 lg:py-32">
      <div className="absolute inset-0 -z-10 bg-hero-radial" />
      <div className="absolute inset-0 -z-10 bg-[url('/grid.svg')] bg-cover bg-center opacity-30" />
      <div className="absolute left-1/2 top-24 -z-10 h-80 w-80 -translate-x-1/2 rounded-full bg-brand-violet/30 blur-3xl" />

      <Container className="grid items-center gap-12 lg:grid-cols-[1.05fr_0.95fr]">
        <div>
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-6 inline-flex items-center gap-2 rounded-full border border-borderSoft/80 bg-surface/70 px-4 py-2 text-sm text-[rgb(var(--muted))] backdrop-blur"
          >
            <span className="h-2 w-2 rounded-full bg-brand-lime" />
            AI-платформа для технологического R&D
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 22 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05, duration: 0.6 }}
            className="max-w-4xl text-5xl font-black tracking-[-0.06em] sm:text-6xl lg:text-7xl"
          >
            <span className="premium-gradient-text">Materials AI</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 22 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1, duration: 0.6 }}
            className="mt-7 max-w-2xl text-lg leading-9 text-[rgb(var(--muted))] sm:text-xl"
          >
            Интеллектуальная оптимизация синтеза материалов и технологических процессов на основе AI и данных диагностики.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 22 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.16, duration: 0.6 }}
            className="mt-9 flex flex-col gap-3 sm:flex-row"
          >
            <ButtonLink href="#contact">Получить консультацию</ButtonLink>
            <ButtonLink href="#solution" variant="ghost" className="gap-2">
              Запросить демо <ArrowRight size={17} />
            </ButtonLink>
          </motion.div>

          <div className="mt-10 grid gap-3 sm:grid-cols-3">
            {heroMetrics.map((metric) => (
              <div key={metric.value} className="glass-card rounded-3xl p-4">
                <div className="text-2xl font-black text-brand-violet dark:text-brand-lavender">{metric.value}</div>
                <div className="mt-2 text-xs leading-5 text-[rgb(var(--muted))]">{metric.label}</div>
              </div>
            ))}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.15, duration: 0.7 }}
          className="glass-card relative overflow-hidden rounded-[2rem] p-5 sm:p-7"
        >
          <div className="absolute right-8 top-8 h-28 w-28 rounded-full bg-brand-lime/20 blur-2xl" />
          <div className="grid gap-4">
            <div className="rounded-3xl bg-background/55 p-5">
              <div className="mb-4 flex items-center gap-3 text-sm font-semibold text-[rgb(var(--muted))]">
                <DatabaseZap className="text-brand-lime" />
                Поток данных
              </div>
              <div className="grid gap-3">
                {['XRD / SEM / TEM / SPM', 'Параметры процесса', 'Целевые свойства'].map((item) => (
                  <div key={item} className="rounded-2xl border border-borderSoft/70 bg-surface/70 px-4 py-3 text-sm">
                    {item}
                  </div>
                ))}
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="rounded-3xl bg-brand-violet/20 p-5">
                <Cpu className="mb-4 text-brand-violet dark:text-brand-lavender" />
                <div className="text-sm font-semibold">ML-модель</div>
                <p className="mt-2 text-xs leading-5 text-[rgb(var(--muted))]">Прогноз структуры и свойств материала.</p>
              </div>
              <div className="rounded-3xl bg-brand-lime/20 p-5">
                <LineChart className="mb-4 text-brand-lime" />
                <div className="text-sm font-semibold">Dashboard</div>
                <p className="mt-2 text-xs leading-5 text-[rgb(var(--muted))]">Рекомендации и аналитика для клиента.</p>
              </div>
            </div>
          </div>
        </motion.div>
      </Container>
    </section>
  );
}
