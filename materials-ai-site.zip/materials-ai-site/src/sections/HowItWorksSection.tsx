import { AnimatedSection } from '@/components/AnimatedSection';
import { Container } from '@/components/Container';
import { SectionHeader } from '@/components/SectionHeader';
import { workflowSteps } from '@/data/site';

export function HowItWorksSection() {
  return (
    <AnimatedSection id="workflow">
      <Container>
        <SectionHeader
          eyebrow="Как работает Materials AI"
          title="От исходных данных до клиентского кабинета"
          text="Процесс построен так, чтобы инженерная задача не терялась между лабораторией, таблицами, моделями и отчётами. Каждый этап оставляет проверяемый цифровой след."
        />

        <div className="grid gap-4 lg:grid-cols-7">
          {workflowSteps.map((step, index) => (
            <article key={step.title} className="glass-card rounded-3xl p-5 lg:min-h-64">
              <div className="mb-6 flex h-11 w-11 items-center justify-center rounded-2xl bg-brand-violet text-sm font-black text-white">
                {index + 1}
              </div>
              <h3 className="text-lg font-semibold">{step.title}</h3>
              <p className="mt-4 text-sm leading-7 text-[rgb(var(--muted))]">{step.text}</p>
            </article>
          ))}
        </div>
      </Container>
    </AnimatedSection>
  );
}
