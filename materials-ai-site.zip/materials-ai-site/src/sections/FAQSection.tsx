import { AnimatedSection } from '@/components/AnimatedSection';
import { Container } from '@/components/Container';
import { SectionHeader } from '@/components/SectionHeader';
import { faqItems } from '@/data/faq';

export function FAQSection() {
  return (
    <AnimatedSection id="faq">
      <Container>
        <SectionHeader
          eyebrow="FAQ"
          title="Частые вопросы"
          text="Короткие ответы на вопросы, которые обычно возникают до пилотного проекта или демонстрации."
          centered
        />

        <div className="mx-auto grid max-w-4xl gap-4">
          {faqItems.map((item) => (
            <details key={item.question} className="glass-card group rounded-3xl p-5 open:shadow-premium">
              <summary className="cursor-pointer list-none text-lg font-semibold marker:hidden">
                {item.question}
              </summary>
              <p className="mt-4 text-sm leading-7 text-[rgb(var(--muted))]">{item.answer}</p>
            </details>
          ))}
        </div>
      </Container>
    </AnimatedSection>
  );
}
