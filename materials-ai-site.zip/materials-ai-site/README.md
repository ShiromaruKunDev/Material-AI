# Materials AI Site

Одностраничный сайт-визитка для проекта **Materials AI**: интеллектуальная оптимизация синтеза материалов и технологических процессов на основе диагностических данных, машинного обучения и AI-ассистента.

## Стек

- Next.js App Router
- TypeScript
- Tailwind CSS
- Framer Motion
- Fake API route для формы обратной связи
- Автоматическая загрузка команды из папки `/team`

## Быстрый запуск

```bash
npm install
npm run dev
```

После запуска откройте:

```bash
http://localhost:3000
```

## Production build

```bash
npm run build
npm run start
```

## Структура проекта

```text
materials-ai-site/
  public/
    favicon.svg
    grid.svg
  team/
    zakasovsky/
      info.txt
      photo.jpg        # опционально
    kumar/
      info.txt
      photo.jpg        # опционально
    yurkov/
      info.txt
      photo.jpg        # опционально
    slepec/
      info.txt
      photo.jpg        # опционально
  src/
    app/
      api/contact/route.ts
      globals.css
      layout.tsx
      page.tsx
    components/
    data/
    lib/
    sections/
    styles/
    types/
```

## Как работает папка `/team`

Сайт читает участников команды на серверной стороне из корневой папки `/team`.

Для каждого участника создаётся отдельная папка:

```text
/team/slug/info.txt
/team/slug/photo.jpg
```

Файл `photo.jpg` необязателен. Если фото нет, карточка покажет аккуратную графическую заглушку с инициалами.

Поддерживаемый формат `info.txt`:

```text
ФИО: Закасовский Игорь Николаевич
Роль: Автор проекта / ML и материалы
Описание: Разрабатывает методологию применения машинного обучения для оптимизации технологических параметров синтеза функциональных материалов.
```

Также поддерживается упрощённый формат из трёх строк:

```text
Закасовский Игорь Николаевич
Автор проекта / ML и материалы
Разрабатывает методологию применения машинного обучения для оптимизации технологических параметров синтеза функциональных материалов.
```

## Как менять контент

Основной текст сайта лежит в папке:

```text
src/data/
```

Файлы:

- `site.ts` — навигация, контакты, тезисы Hero, pipeline, преимущества;
- `services.ts` — карточки услуг;
- `pricing.ts` — тарифы;
- `faq.ts` — вопросы и ответы.

Секции сайта расположены в:

```text
src/sections/
```

Общие UI-компоненты находятся в:

```text
src/components/
```

Глобальные стили и CSS-переменные:

```text
src/app/globals.css
src/styles/variables.css
```

## Форма обратной связи

Форма отправляет данные в fake API route:

```text
src/app/api/contact/route.ts
```

Сейчас API только валидирует поля и возвращает успешный ответ. Для реальной интеграции замените обработчик на отправку в CRM, почту, Telegram bot или собственный backend.

## SEO

Базовые SEO-метаданные заданы в:

```text
src/app/layout.tsx
```

Для продакшена замените `metadataBase` и Open Graph URL на фактический домен проекта.
