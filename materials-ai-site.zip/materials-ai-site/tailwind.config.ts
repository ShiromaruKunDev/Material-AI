import type { Config } from 'tailwindcss';

const config: Config = {
  darkMode: 'class',
  content: [
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/sections/**/*.{js,ts,jsx,tsx,mdx}',
    './src/data/**/*.{js,ts,jsx,tsx,mdx}'
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          violet: '#8E7ACE',
          lavender: '#B68DCE',
          lime: '#C5E36C',
          cloud: '#EDEDED',
          ink: '#11121D'
        },
        surface: 'rgb(var(--surface) / <alpha-value>)',
        borderSoft: 'rgb(var(--border-soft) / <alpha-value>)',
        foreground: 'rgb(var(--foreground) / <alpha-value>)',
        background: 'rgb(var(--background) / <alpha-value>)'
      },
      boxShadow: {
        premium: '0 24px 80px rgb(18 20 37 / 0.16)',
        glow: '0 0 60px rgb(142 122 206 / 0.32)'
      },
      backgroundImage: {
        'hero-radial':
          'radial-gradient(circle at 20% 20%, rgba(182,141,206,0.32), transparent 32%), radial-gradient(circle at 80% 10%, rgba(197,227,108,0.22), transparent 30%), linear-gradient(135deg, rgba(142,122,206,0.22), rgba(237,237,237,0.05))'
      },
      borderRadius: {
        '3xl': '1.75rem'
      }
    }
  },
  plugins: []
};

export default config;
